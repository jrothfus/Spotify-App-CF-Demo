# NotFound

**Properties**

| Name  | Type                          | Required | Description |
| :---- | :---------------------------- | :------- | :---------- |
| error | [ErrorObject](ErrorObject.md) | ✅       |             |
