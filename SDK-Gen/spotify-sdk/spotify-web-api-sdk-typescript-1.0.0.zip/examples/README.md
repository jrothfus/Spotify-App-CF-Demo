# spotify-web-api-sdk

A basic example of how to use the spotify-web-api-sdk package.

## Installation

In the event `spotify-web-api-sdk` is not published to npm, you can install it locally by running the following command in the examples folder:

```sh
npm run setup
```

This will rebuild the parent package and install it locally.

Otherwise you can install it from npm:

```sh
npm install spotify-web-api-sdk
```

## Usage

To run the example, run the following command in the examples folder:

```sh
npm run start
```
